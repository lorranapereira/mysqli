<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="main.php" method="post">
        <select name="option" id="" >
            <option value="Inserir">Inserir</option>
            <option value="Buscar">Buscar</option>
            <option value="Deletar">Deletar</option>
            <option value="Alterar">Alterar</option>
        </select>
        <button type="submit">Enviar</button>
    </form>
</body>
</html>