<?php
require_once("DAO.php");
$dmed = new MedicacaoDAO();
echo $_POST["option"];
if ($_POST["option"] == "Alterar") {
    header("cod.php");
    echo $_POST["codigo"];
}
?>
