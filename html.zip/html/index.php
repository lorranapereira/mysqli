<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="main.php" method="post" >
        <label for="">meicaçao</label>
        <input type="text" name="medicacao">
        <label for="">codigo</label>
        <input type="text" name="codigo">
        <label for="">fabricaçao</label>
        <input name="fabricante" type="text">
        <label for="">controle</label>
        <input name="controle" type="text">
        <label for="">quantidade</label>
        <input name="quantidade" type="text">
        <label for="">preco</label>
        <input name="preco" type="text">
        <button type="submit" >enviar</button>
    </form>
</body>
</html>