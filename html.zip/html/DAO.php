<?php 

class MedicacaoDAO {
    private function CriaConexao()
    { 
        $conexao = mysqli_connect("localhost","root","","TESTE");
        return $conexao;
    }
    public function inserir($medicacao)
    {                
        $conn = $this->CriaConexao();
        $temp_nome_med = $medicacao->getNome_medicacao();
        $temp_nome_codigo = $medicacao->getCodigo();
        $temp_nome_fabri = $medicacao->getNome_fabricante();
        $temp_controle = $medicacao->getControle();
        $temp_quant = $medicacao->getQuantidade();
        $temp_preco = $medicacao->getPreco();

        /*$sql = "INSERT INTO Medicacao (nome_medicacao,codigo,nome_fabricante,controle,quantidade,preco) VALUES ($temp_nome_med,$temp_nome_codigo,$temp_nome_fabri,$temp_controle,$temp_quant,$temp_preco)";


        echo $sql;
        */
        /*if (!mysqli_query($conn,$sql)){
            echo "ERROR";
        } else {
            echo "OK";
        }
        */

        $sql = "INSERT INTO Medicacao (nome_medicacao,codigo,nome_fabricante,controle,quantidade,preco) VALUES (?,?,?,?,?,?)";


        if ($stmt = mysqli_prepare($conn, $sql)) {

            /* bind parameters for markers */
            mysqli_stmt_bind_param($stmt, "sissid", $temp_nome_med, $temp_nome_codigo,$temp_nome_fabri, $temp_controle, $temp_quant, $temp_preco);
            mysqli_stmt_execute($stmt);
        
        }
        mysqli_close($conn);
    }
    public function deletar($cod){
        $conn = $this->CriaConexao();
        $sql = "DELETE FROM Medicacao WHERE codigo = ?";

        if ($stmt = mysqli_prepare($conn, $sql)) {

            /* bind parameters for markers */
            mysqli_stmt_bind_param($stmt, "i", $cod);
            mysqli_stmt_execute($stmt);
        
        }
    mysqli_close($conn);
    }

}
?>