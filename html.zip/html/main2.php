<?php
require_once("DAO.php");
$dmed = new MedicacaoDAO();
echo $_POST["option"];
echo $_POST["codigo"];

?>
